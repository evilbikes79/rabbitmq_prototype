<?php

	class CaliperAssessmentAttempt extends BaseModel {

		public function CaliperAssessmentAttempt($assessmentId, $attemptNo) {

			private $assessment_id;
			private $attempt_number;

		}

	}

?>